-- Posting Count
SELECT a.id
      ,display_name
      ,COUNT( b.id ) count
FROM wp_users a
LEFT OUTER JOIN wp_posts b ON a.id = b.post_author
AND post_status    =  'publish'
AND comment_status =  'open'
GROUP BY display_name
ORDER BY count DESC
LIMIT 5
;

-- KBoard Count
SELECT b.id
      ,display_name
      ,count(a.uid) count
FROM wp_kboard_board_content a, wp_users b
WHERE a.member_uid = b.id
GROUP BY a.member_uid
ORDER BY count DESC
LIMIT 5
;

-- Comment Count
SELECT a.id
      ,display_name
      ,count(uid) count
FROM wp_users a
LEFT OUTER JOIN wp_kboard_comments b ON a.id = b.user_uid
GROUP BY display_name
ORDER BY count DESC
LIMIT 5
;

-- Member's Point
SELECT a.id
      ,a.display_name
      ,(a.count + b.count) * 5 + c.count as point
FROM(
      SELECT a.id
            ,display_name 
            ,COUNT( b.id ) count
      FROM wp_users a
      LEFT OUTER JOIN wp_posts b ON a.id = b.post_author
      AND post_status    =  'publish'
      AND comment_status =  'open'
      GROUP BY display_name
    ) a,
    (
      SELECT b.id
            ,display_name
            ,count(a.uid) count
      FROM wp_kboard_board_content a
          ,wp_users b
      WHERE a.member_uid = b.id
      GROUP BY a.member_uid
    ) b,
    (
      SELECT a.id, display_name, count(uid) count
      FROM wp_users a
      LEFT OUTER JOIN wp_kboard_comments b ON a.id = b.user_uid
      GROUP BY display_name
      ORDER BY count DESC
    ) c
WHERE a.id = b.id
AND   a.id = c.id
ORDER BY point DESC
LIMIT 5
;

-- View Rank
SELECT title
      ,member_display
      ,view
FROM   wp_kboard_board_content
WHERE  board_id in (1,2,3,4,5,6,7,8,9,10)
AND    notice != true
ORDER BY view DESC
LIMIT 10
;

-- Comment Rank
SELECT title
      ,member_display
      ,comment
FROM   wp_kboard_board_content
WHERE  board_id in (1,2,3,4,5,6,7,8,9,10) -- Hub only
AND    notice != true
ORDER BY comment DESC
LIMIT 10
;

-- Latest true? false?
SELECT MAX( uid )
      ,b.id, a.member_uid
      ,name
      ,member_display
      ,IF( DATEDIFF( NOW( ) , STR_TO_DATE( MAX( DATE ) ,  '%Y%m%d %H%i%s' ) ) <=1, true, false ) latest
FROM wp_kboard_board_content a
RIGHT OUTER JOIN wp_members b ON b.name = a.member_display
AND board_id IN ( 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ) 
AND notice   != true
GROUP BY member_uid
ORDER BY b.id
;